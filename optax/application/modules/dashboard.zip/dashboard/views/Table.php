<div class="card card-custom card-stretch gutter-b">
	<!--begin::Header-->
	<div class="card-header h-auto border-0">
		<div class="card-title py-5">
			<div class="row">
				<div class="col-10">
					<h3 class="m-0">
						<span class="d-block text-dark font-weight-bolder" id="dashboardTitle">Dashboard Pajak</span>
					</h3>
				</div>
				<div class="col-2">
					<span class="switch switch-light-primary float-left switch-sm">
						<label>
							<input type="checkbox" onchange="switchDashboard()" id="toggleDashboard" />
							<span></span>
						</label>
					</span>
				</div>
			</div>
		</div>
		<div class="card-toolbar" id="toolbar-pajak">
			<span class="text-muted font-weight-bold mr-2">Tampilkan Berdasarkan :</span>
			<button id="btn-show-tanggal" class="btn btn-primary btn-sm mr-1" data-value="tanggal" onclick="changeBerdasarkan(this)">Tanggal</button>
			<button id="btn-show-bulan" class="btn btn-default btn-sm mr-1" data-value="bulan" onclick="changeBerdasarkan(this)">Bulan</button>
			<div class="dropdown dropdown-inline" data-toggle="tooltip" title="Quick actions" data-placement="left">
				<a href="#" class="btn btn-success btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<i class="fa fa-calendar-day"></i>
					<span class="mr-2" id="text-calendar">----/--/--</span>
					<i class="fa fa-angle-down m-0 p-0"></i>
				</a>
				<div class="dropdown-menu mt-1 p-0 m-0 dropdown-menu-md dropdown-menu-right">
					<!--begin::Navigation-->
					<ul class="navi navi-hover">
						<li class="navi-header font-weight-bold py-4">
							<span class="font-size-lg">Tampilkan berdasarkan:</span>
						</li>
						<li class="navi-separator mb-3 opacity-70"></li>
						<li class="navi-item p-2">
							<form id="tanggal" name="tanggal" action="javascript:filter()">
								<div class="form-group">
									<label style="font-size: 12px;">Tanggal :</label>
									<input type="date" name="awal_tanggal" id="awal_tanggal" class="form-control" value="<?php echo date_format((new DateTime(date('Y-m-d')))->modify('-7 day'), 'Y-m-d'); ?>">
								</div>
								<div class="form-group">
									<label style="font-size: 12px;">Sampai Dengan :</label>
									<input type="date" name="akhir_tanggal" id="akhir_tanggal" class="form-control" value="<?php echo date('Y-m-d'); ?>">
								</div>
								<div class="form-group">
									<label style="font-size: 12px;">Bulan :</label>
									<input type="month" class="form-control" name="bulan" id="bulan" value="<?php echo date('Y-m') ?>">
								</div>
								<div class="form-group">
									<button type="submit" class="btn btn-success btn-sm mt-2 mb-2 float-right"><span class="fas fa-search"></span> Tampilkan</button>
								</div>
							</form>
						</li>
					</ul>
					<!--end::Navigation-->
				</div>
			</div>
		</div>

		<div class="card-toolbar" id="toolbar-pos" style="display: none;">
			<span class="text-muted font-weight-bold mr-2">Filter Penjualan :</span>
			<button id="btn-show-tanggal-pos" class="btn btn-primary btn-sm mr-1" data-value="tanggal" onclick="changeBerdasarkanPos(this)">Tanggal</button>
			<button id="btn-show-bulan-pos" class="btn btn-default btn-sm mr-1" data-value="bulan" onclick="changeBerdasarkanPos(this)">Bulan</button>
			<div class="dropdown dropdown-inline" data-toggle="tooltip" title="Quick actions" data-placement="left">
				<a href="#" class="btn btn-success btn-sm" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					<i class="fa fa-calendar-day"></i>
					<span class="mr-2" id="text-calendar-pos">----/--/--</span>
					<i class="fa fa-angle-down m-0 p-0"></i>
				</a>
				<div class="dropdown-menu mt-1 p-0 m-0 dropdown-menu-md dropdown-menu-right">
					<!--begin::Navigation-->
					<ul class="navi navi-hover">
						<li class="navi-header font-weight-bold py-4">
							<span class="font-size-lg">Tampilkan berdasarkan:</span>
						</li>
						<li class="navi-separator mb-3 opacity-70"></li>
						<li class="navi-item p-2">
							<form id="tanggal-pos" name="tanggal" action="javascript:filterPos()">
								<div class="form-group">
									<label style="font-size: 12px;">Tanggal :</label>
									<input type="date" name="awal_tanggal" id="awal_tanggal-pos" class="form-control" value="<?php echo date_format((new DateTime(date('Y-m-d')))->modify('-7 day'), 'Y-m-d'); ?>">
								</div>
								<div class="form-group">
									<label style="font-size: 12px;">Sampai Dengan :</label>
									<input type="date" name="akhir_tanggal" id="akhir_tanggal-pos" class="form-control" value="<?php echo date('Y-m-d'); ?>">
								</div>
								<div class="form-group" id="handlePosBulan">
									<label style="font-size: 12px;">Bulan :</label>
									<input type="month" class="form-control" name="bulan" id="bulan-pos" value="<?php echo date('Y-m') ?>">
								</div>
								<div class="form-group">
									<button type="submit" class="btn btn-success btn-sm mt-2 mb-2 float-right"><span class="fas fa-search"></span> Tampilkan</button>
								</div>
							</form>
						</li>
					</ul>
					<!--end::Navigation-->
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Dashboard Pajak -->
<div id="dashboardPajak">
	<div class="row">
		<div class="col-lg-4">
			<div class="card card-custom bgi-no-repeat card-stretch gutter-b">
				<!--begin::Body-->
				<div class="card-body">
					<div class="d-flex align-items-center">
						<span class="svg-icon svg-icon-3x svg-icon-primary mb-auto mt-auto mr-3">
							<!--begin::Svg Icon | path:/var/www/preview.keenthemes.com/metronic/releases/2021-05-14-112058/theme/html/demo4/dist/../src/media/svg/icons/Shopping/Money.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
								<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
									<rect x="0" y="0" width="24" height="24" />
									<path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z" fill="#000000" opacity="0.3" transform="translate(11.500000, 12.000000) rotate(-345.000000) translate(-11.500000, -12.000000) " />
									<path d="M2,6 L21,6 C21.5522847,6 22,6.44771525 22,7 L22,17 C22,17.5522847 21.5522847,18 21,18 L2,18 C1.44771525,18 1,17.5522847 1,17 L1,7 C1,6.44771525 1.44771525,6 2,6 Z M11.5,16 C13.709139,16 15.5,14.209139 15.5,12 C15.5,9.790861 13.709139,8 11.5,8 C9.290861,8 7.5,9.790861 7.5,12 C7.5,14.209139 9.290861,16 11.5,16 Z M11.5,14 C12.6045695,14 13.5,13.1045695 13.5,12 C13.5,10.8954305 12.6045695,10 11.5,10 C10.3954305,10 9.5,10.8954305 9.5,12 C9.5,13.1045695 10.3954305,14 11.5,14 Z" fill="#000000" />
								</g>
							</svg>
							<!--end::Svg Icon-->
						</span>
						<span id="total_pajak_masuk" class="card-title font-weight-bolder text-dark font-size-h2 mb-0 mr-3 h1">0</span>
						<span class="font-weight-bold text-muted d-none">+0%</span>
					</div>
					<span class="font-weight-bold text-muted d-block">Total Pajak Masuk</span>
				</div>
				<!--end::Body-->
			</div>
		</div>
		<div class="col-lg-4">
			<div class="card card-custom bgi-no-repeat card-stretch gutter-b">
				<!--begin::Body-->
				<div class="card-body">
					<div class="d-flex align-items-center">
						<span class="svg-icon svg-icon-3x svg-icon-primary mb-auto mt-auto mr-3">
							<!--begin::Svg Icon | path:/var/www/preview.keenthemes.com/metronic/releases/2021-05-14-112058/theme/html/demo3/dist/../src/media/svg/icons/Shopping/Cart1.svg-->
							<span class="svg-icon svg-icon-primary svg-icon-2x">
								<!--begin::Svg Icon | path:C:\wamp64\www\keenthemes\themes\metronic\theme\html\demo3\dist/../src/media/svg/icons\Navigation\Double-check.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<polygon points="0 0 24 0 24 24 0 24" />
										<path d="M9.26193932,16.6476484 C8.90425297,17.0684559 8.27315905,17.1196257 7.85235158,16.7619393 C7.43154411,16.404253 7.38037434,15.773159 7.73806068,15.3523516 L16.2380607,5.35235158 C16.6013618,4.92493855 17.2451015,4.87991302 17.6643638,5.25259068 L22.1643638,9.25259068 C22.5771466,9.6195087 22.6143273,10.2515811 22.2474093,10.6643638 C21.8804913,11.0771466 21.2484189,11.1143273 20.8356362,10.7474093 L17.0997854,7.42665306 L9.26193932,16.6476484 Z" fill="#000000" fill-rule="nonzero" opacity="0.3" transform="translate(14.999995, 11.000002) rotate(-180.000000) translate(-14.999995, -11.000002) " />
										<path d="M4.26193932,17.6476484 C3.90425297,18.0684559 3.27315905,18.1196257 2.85235158,17.7619393 C2.43154411,17.404253 2.38037434,16.773159 2.73806068,16.3523516 L11.2380607,6.35235158 C11.6013618,5.92493855 12.2451015,5.87991302 12.6643638,6.25259068 L17.1643638,10.2525907 C17.5771466,10.6195087 17.6143273,11.2515811 17.2474093,11.6643638 C16.8804913,12.0771466 16.2484189,12.1143273 15.8356362,11.7474093 L12.0997854,8.42665306 L4.26193932,17.6476484 Z" fill="#000000" fill-rule="nonzero" transform="translate(9.999995, 12.000002) rotate(-180.000000) translate(-9.999995, -12.000002) " />
									</g>
								</svg>
								<!--end::Svg Icon-->
							</span>
							<!--end::Svg Icon-->
						</span>
						<span id="total_realisasi_wajib_pajak" class="card-title font-weight-bolder text-dark font-size-h2 mb-0 mr-3 h1">0</span>
						<span class="font-weight-bold text-muted d-none">+0%</span>
					</div>
					<span class="font-weight-bold text-muted d-block">Total Realisasi Wajib Pajak</span>
				</div>
				<!--end::Body-->
			</div>
		</div>

		<div class="col-lg-4">
			<div class="card card-custom bgi-no-repeat card-stretch gutter-b">
				<!--begin::Body-->
				<div class="card-body">
					<div class="d-flex align-items-center">
						<span class="svg-icon svg-icon-3x svg-icon-primary mb-auto mt-auto mr-3">
							<!--begin::Svg Icon | path:/var/www/preview.keenthemes.com/metronic/releases/2021-05-14-112058/theme/html/demo3/dist/../src/media/svg/icons/Shopping/Cart2.svg-->
							<span class="svg-icon svg-icon-primary svg-icon-2x">
								<!--begin::Svg Icon | path:C:\wamp64\www\keenthemes\themes\metronic\theme\html\demo3\dist/../src/media/svg/icons\Home\Home.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
									<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
										<rect x="0" y="0" width="24" height="24" />
										<path d="M3.95709826,8.41510662 L11.47855,3.81866389 C11.7986624,3.62303967 12.2013376,3.62303967 12.52145,3.81866389 L20.0429,8.41510557 C20.6374094,8.77841684 21,9.42493654 21,10.1216692 L21,19.0000642 C21,20.1046337 20.1045695,21.0000642 19,21.0000642 L4.99998155,21.0000673 C3.89541205,21.0000673 2.99998155,20.1046368 2.99998155,19.0000673 L2.99999828,10.1216672 C2.99999935,9.42493561 3.36258984,8.77841732 3.95709826,8.41510662 Z M10,13 C9.44771525,13 9,13.4477153 9,14 L9,17 C9,17.5522847 9.44771525,18 10,18 L14,18 C14.5522847,18 15,17.5522847 15,17 L15,14 C15,13.4477153 14.5522847,13 14,13 L10,13 Z" fill="#000000" />
									</g>
								</svg>
								<!--end::Svg Icon-->
							</span>
							<!--end::Svg Icon-->
						</span>
						<span id="total_wajib_pajak" class="card-title font-weight-bolder text-dark font-size-h2 mb-0 mr-3 h1">0</span>
						<span class="font-weight-bold text-muted d-none">+0%</span>
					</div>
					<span class="font-weight-bold text-muted d-block">Total Wajib Pajak</span>
				</div>
				<!--end::Body-->
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-lg-8">
			<div class="card card-custom card-stretch gutter-b">
				<!--begin::Header-->
				<div class="card-header border-0">
					<div class="card-title py-5">
						<h3 class="card-label">
							<span class="d-block text-dark font-weight-bolder">Statistik Nominal Realisasi Pajak</span>
						</h3>
					</div>
					<div class="card-toolbar">
						<div id="spinner-statistik-nominal" class="spinner-border text-primary d-none mx-5" role="status">
							<span class="sr-only">Loading...</span>
						</div>
						<span class="text-muted font-weight-bold mr-2">Tampilkan Berdasarkan :</span>
						<div>
							<select class="form-control select2" id="filter-jenis_usaha" onchange="filterJenisUsaha('tanggal',this)"></select>
						</div>
					</div>
				</div>
				<!--end::Header-->
				<!--begin::Body-->
				<div class="card-body" style="position: relative;">
					<div id="chartrealisasipajak" style="min-height: 365px;"></div>
				</div>
				<!--end::Body-->
			</div>
		</div>
		<div class="col-lg-4">
			<div class="card card-custom card-stretch gutter-b" style="height: 250px;">
				<div class="card-header h-auto border-0">
					<div class="card-title py-5">
						<h3 class="card-label">
							<span class="d-block text-dark font-weight-bolder">Sektor Usaha</span>
						</h3>
					</div>
				</div>
				<div class="card-body pt-0">
					<div id="sektor_usaha" class="d-flex flex-column" style="height:150px;overflow-y:auto;overflow-x:hidden;">
					</div>
				</div>
			</div>
			<div class="card card-custom gutter-b d-flex flex-column" >
				<div class="card-header h-auto border-0">
					<div class="card-title py-5 w-100 d-flex justify-content-between">
						<h3 class="card-label">
							<span class="text-dark font-weight-bolder">Online Users</span>
						</h3>
					</div>
				</div>
				<div class="card-body pt-0">
					<div class="d-flex flex-column" id="user_active_dashboard" style="height:250px;overflow-y:auto;overflow-x:hidden;">
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-lg-4">
			<div class="card card-custom gutter-b d-flex flex-column" style="height: 300px;">
				<div class="card-header h-auto border-0">
					<div class="card-title py-5">
						<h3 class="card-label">
							<span class="d-block text-dark font-weight-bolder">Tempat Usaha</span>
						</h3>
					</div>
				</div>
				<div class="card-body pt-0" id="toko_baru" style="height:430px;overflow-y:auto;overflow-x:hidden;">

				</div>
			</div>
			<div class="card card-custom gutter-b d-flex flex-column">
				<div class="card-header h-auto border-0">
					<div class="card-title py-5 w-100 d-flex justify-content-between">
						<h3 class="card-label">
							<span class="text-dark font-weight-bolder">Target Pajak</span>
						</h3>
						<small>Tahun <span id="target_pajak_tahun">-</span></small>
					</div>
				</div>
				<div class="card-body pt-0">
					<span id="target_pajak" class="font-weight-bolder text-dark h1 d-block">0</span>
				</div>
				<div class="card-header h-auto border-0">
					<div class="card-title py-5">
						<h3 class="card-label">
							<span class="d-block text-dark font-weight-bolder">Pajak Belum dibayar</span>
						</h3>
					</div>
				</div>
				<div class="card-body pt-0">
					<span id="pajak_belum_bayar" class="font-weight-bolder text-dark h1 d-block">0</span>
				</div>
			</div>
		</div>
		<div class="col-lg-8">

			<div class="card card-custom card-stretch gutter-b">
				<!--begin::Header-->
				<div class="card-header border-0">
					<div class="card-title py-5">
						<h3 class="card-label">
							<span class="d-block text-dark font-weight-bolder">Statistik Total Realisasi Pajak</span>
						</h3>
					</div>
					<div class="card-toolbar">
						<div id="spinner-statistik-pembelian" class="spinner-border text-primary d-none" role="status">
							<span class="sr-only">Loading...</span>
						</div>
					</div>
				</div>
				<!--end::Header-->
				<!--begin::Body-->
				<div class="card-body" style="position: relative;">
					<div id="chartrealisasipajakupload" style="min-height: 465px;"></div>
				</div>
				<!--end::Body-->
			</div>
		</div>
	</div>
</div>

<!-- Dashboard POS -->
<div id="dashboardPOS">
	<div class="row">
		<div class="col-lg-12">
			<div class="card card-custom bgi-no-repeat card-stretch gutter-b">
				<!--begin::Body-->
				<div class="card-body">
					<div class="d-flex align-items-center">
						<span class="svg-icon svg-icon-3x svg-icon-primary mb-auto mt-auto mr-3">
							<!--begin::Svg Icon | path:/var/www/preview.keenthemes.com/metronic/releases/2021-05-14-112058/theme/html/demo3/dist/../src/media/svg/icons/Shopping/Cart2.svg-->
							<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
								<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
									<rect x="0" y="0" width="24" height="24" />
									<path d="M12,4.56204994 L7.76822128,9.6401844 C7.4146572,10.0644613 6.7840925,10.1217854 6.3598156,9.76822128 C5.9355387,9.4146572 5.87821464,8.7840925 6.23177872,8.3598156 L11.2317787,2.3598156 C11.6315738,1.88006147 12.3684262,1.88006147 12.7682213,2.3598156 L17.7682213,8.3598156 C18.1217854,8.7840925 18.0644613,9.4146572 17.6401844,9.76822128 C17.2159075,10.1217854 16.5853428,10.0644613 16.2317787,9.6401844 L12,4.56204994 Z" fill="#000000" fill-rule="nonzero" opacity="0.3" />
									<path d="M3.28077641,9 L20.7192236,9 C21.2715083,9 21.7192236,9.44771525 21.7192236,10 C21.7192236,10.0817618 21.7091962,10.163215 21.6893661,10.2425356 L19.5680983,18.7276069 C19.234223,20.0631079 18.0342737,21 16.6576708,21 L7.34232922,21 C5.96572629,21 4.76577697,20.0631079 4.43190172,18.7276069 L2.31063391,10.2425356 C2.17668518,9.70674072 2.50244587,9.16380623 3.03824078,9.0298575 C3.11756139,9.01002735 3.1990146,9 3.28077641,9 Z M12,12 C11.4477153,12 11,12.4477153 11,13 L11,17 C11,17.5522847 11.4477153,18 12,18 C12.5522847,18 13,17.5522847 13,17 L13,13 C13,12.4477153 12.5522847,12 12,12 Z M6.96472382,12.1362967 C6.43125772,12.2792385 6.11467523,12.8275755 6.25761704,13.3610416 L7.29289322,17.2247449 C7.43583503,17.758211 7.98417199,18.0747935 8.51763809,17.9318517 C9.05110419,17.7889098 9.36768668,17.2405729 9.22474487,16.7071068 L8.18946869,12.8434035 C8.04652688,12.3099374 7.49818992,11.9933549 6.96472382,12.1362967 Z M17.0352762,12.1362967 C16.5018101,11.9933549 15.9534731,12.3099374 15.8105313,12.8434035 L14.7752551,16.7071068 C14.6323133,17.2405729 14.9488958,17.7889098 15.4823619,17.9318517 C16.015828,18.0747935 16.564165,17.758211 16.7071068,17.2247449 L17.742383,13.3610416 C17.8853248,12.8275755 17.5687423,12.2792385 17.0352762,12.1362967 Z" fill="#000000" />
								</g>
							</svg>
							<!--end::Svg Icon-->
						</span>
						<span id="total_penjualan_barang" class="card-title font-weight-bolder text-dark font-size-h2 mb-0 mr-3 h1">0</span>
						<span class="font-weight-bold text-muted d-none">+0%</span>
					</div>
					<span class="font-weight-bold text-muted d-block">Total penjualan dari wajib pajak</span>
				</div>
				<!--end::Body-->
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-lg-12">
			<div class="card card-custom card-stretch gutter-b">
				<!--begin::Header-->
				<div class="card-header h-auto border-0">
					<div class="card-title py-5">
						<h3 class="card-label">
							<span class="d-block text-dark font-weight-bolder">Statistik Penjualan POS</span>
						</h3>
					</div>
					<div class="card-toolbar">
						<div id="spinner-statistik-nominal" class="spinner-border text-primary d-none mx-5" role="status">
							<span class="sr-only">Loading...</span>
						</div>
						<span class="text-muted font-weight-bold mr-2">Tampilkan Berdasarkan :</span>
						<div>
							<select class="form-control select2" id="filter-jenis_usaha-pos" onchange="dashboardPOS('tanggal',this)"></select>
						</div>
					</div>
				</div>
				<!--end::Header-->
				<!--begin::Body-->
				<div class="card-body" style="position: relative;">
					<div id="barChart" style="min-height: 365px;"></div>
				</div>
				<!--end::Body-->
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('javascript'); ?>